using System.Runtime.Serialization;

namespace FootballManager.Contracts;

/// <summary>DTO של פרטי שחקן ודירוגי היכולת. משותף למסכים, לשירות WCF ולמאגר Access.</summary>
[DataContract(Namespace = "urn:footballmanager:contracts")]
public sealed class PlayerDto
{
    [DataMember(Order = 1)] public int PlayerId { get; set; }
    [DataMember(Order = 2)] public string FirstName { get; set; } = string.Empty;
    [DataMember(Order = 3)] public string LastName { get; set; } = string.Empty;
    [DataMember(Order = 4)] public int Age { get; set; }
    [DataMember(Order = 5)] public string Position { get; set; } = string.Empty;
    [DataMember(Order = 6)] public int Rating { get; set; }
    [DataMember(Order = 7)] public int Speed { get; set; }
    [DataMember(Order = 8)] public int Shooting { get; set; }
    [DataMember(Order = 9)] public int Passing { get; set; }
    [DataMember(Order = 10)] public int Defense { get; set; }

    /// <summary>ממירה את נתוני האובייקט למחרוזת תצוגה עבור המסך או הרשימה. נקראת בקוד מתוך Read Player, Read Team.</summary>
    /// <returns>מחרוזת שמייצגת את תוצאת הפעולה.</returns>
    public override string ToString() =>
        $"{FirstName} {LastName} · {Position} · דירוג {Rating} · גיל {Age}";
}

/// <summary>DTO של פרטי קבוצה, כולל שם, מדינה, ליגה ותקציב; משמש להצגה ולפעולות הקבוצות.</summary>
[DataContract(Namespace = "urn:footballmanager:contracts")]
public sealed class TeamDto
{
    [DataMember(Order = 1)] public int TeamId { get; set; }
    [DataMember(Order = 2)] public string Name { get; set; } = string.Empty;
    [DataMember(Order = 3)] public string Country { get; set; } = string.Empty;
    [DataMember(Order = 4)] public string League { get; set; } = string.Empty;
    [DataMember(Order = 5)] public decimal Budget { get; set; }

    /// <summary>ממירה את נתוני האובייקט למחרוזת תצוגה עבור המסך או הרשימה. נקראת בקוד מתוך Read Player, Read Team.</summary>
    /// <returns>מחרוזת שמייצגת את תוצאת הפעולה.</returns>
    public override string ToString() => $"{Name} · {Country} · {League}";
}

/// <summary>מעטפת תשובת שירות הכוללת הודעת מצב ורשימת שחקנים מסוג PlayerDto.</summary>
[DataContract(Namespace = "urn:footballmanager:contracts")]
public sealed class PlayersResponseDto
{
    [DataMember(Order = 1)] public bool Succeeded { get; set; }
    [DataMember(Order = 2)] public string Message { get; set; } = string.Empty;
    [DataMember(Order = 3)] public List<PlayerDto> Players { get; set; } = [];
}

/// <summary>תשובת ניתוח AI לשחקן. השירות מחזיר את הודעת המצב ואת הניתוח בלי לשמור אותו במסד.</summary>
[DataContract(Namespace = "urn:footballmanager:contracts")]
public sealed class PlayerAnalysisResponseDto
{
    [DataMember(Order = 1)] public bool Succeeded { get; set; }
    [DataMember(Order = 2)] public string Message { get; set; } = string.Empty;
    [DataMember(Order = 3)] public string PlayerName { get; set; } = string.Empty;
    [DataMember(Order = 4)] public string Analysis { get; set; } = string.Empty;
}

/// <summary>מעטפת תשובת שירות הכוללת הודעת מצב ורשימת קבוצות מסוג TeamDto.</summary>
[DataContract(Namespace = "urn:footballmanager:contracts")]
public sealed class TeamsResponseDto
{
    [DataMember(Order = 1)] public bool Succeeded { get; set; }
    [DataMember(Order = 2)] public string Message { get; set; } = string.Empty;
    [DataMember(Order = 3)] public List<TeamDto> Teams { get; set; } = [];
}
